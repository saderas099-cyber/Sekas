package com.nubia.lastsecs

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View
import java.util.Locale
import kotlin.math.*

class TimerView(ctx: Context, private val supplier: () -> Float) : View(ctx) {
    private val p = Prefs(ctx)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density
    private var tf: Typeface = Typeface.DEFAULT
    private var bmp: Bitmap? = null
    private var lastSec = Int.MIN_VALUE
    private var running = false
    var onSecond: ((Int) -> Unit)? = null

    init { setLayerType(LAYER_TYPE_SOFTWARE, null); reload() }

    private fun px() = p.sizeDp * d
    fun w() = (px() * 1.35f).toInt()
    fun h() = ((if (p.shape == 2) px() * 0.62f else px()) * 1.35f).toInt()

    fun reload() {
        tf = when (p.font) {
            0 -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
            1 -> Typeface.SERIF
            2 -> Typeface.MONOSPACE
            3 -> Typeface.create("sans-serif-black", Typeface.NORMAL)
            4 -> Typeface.create("sans-serif-thin", Typeface.NORMAL)
            5 -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
            6 -> Typeface.create("casual", Typeface.NORMAL)
            else -> try { Typeface.createFromFile(p.fontFile) } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        }
        bmp = null
        if (p.bgImage.isNotEmpty()) try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(p.bgImage, o)
            var s = 1
            while (o.outWidth / s > 800) s *= 2
            bmp = BitmapFactory.decodeFile(p.bgImage, BitmapFactory.Options().apply { inSampleSize = s })
        } catch (e: Exception) { }
        requestLayout(); invalidate()
    }

    override fun onMeasure(wm: Int, hm: Int) = setMeasuredDimension(w(), h())
    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; invalidate() }
    override fun onDetachedFromWindow() { running = false; super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val rem = supplier().coerceAtLeast(0f)
        val sec = ceil(rem).toInt()
        if (sec != lastSec) { lastSec = sec; onSecond?.invoke(sec) }
        val t = SystemClock.uptimeMillis() / 1000f
        val s = px()
        val bw = s
        val bh = if (p.shape == 2) s * 0.62f else s
        val cx = width / 2f
        val cy = height / 2f
        val red = 0xFFFF3B30.toInt()
        val warn = rem <= 5f && p.warnRed
        val frac = rem - floor(rem)
        var sc = 1f
        if (p.pulse) sc += 0.08f * frac * frac
        val dx = if (p.shake && rem <= 5f) sin(t * 70f) * s * 0.03f * (1.3f - rem / 5f) else 0f
        canvas.save()
        canvas.translate(dx, 0f)
        canvas.scale(sc, sc, cx, cy)

        val rect = RectF(cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2)
        val r = when (p.shape) { 0 -> s * 0.22f; 1 -> s / 2; else -> bh / 2 }
        val path = Path().apply { addRoundRect(rect, r, r, Path.Direction.CW) }
        val ringCol = if (warn) red else p.ringColor

        // фон + світіння
        paint.reset(); paint.isAntiAlias = true
        if (p.glow) paint.setShadowLayer(s * 0.10f * (0.7f + 0.3f * (0.5f + 0.5f * sin(t * 4f))), 0f, 0f, ringCol)
        paint.style = Paint.Style.FILL
        paint.color = p.bgColor
        if (p.useGradient) paint.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, p.bgColor, p.bgColor2, Shader.TileMode.CLAMP)
        canvas.drawPath(path, paint)
        paint.clearShadowLayer(); paint.shader = null

        bmp?.let { b ->
            canvas.save(); canvas.clipPath(path)
            val k = max(bw / b.width, bh / b.height)
            val m = Matrix(); m.postScale(k, k); m.postTranslate(cx - b.width * k / 2, cy - bh / 2 - (b.height * k - bh) / 2)
            canvas.drawBitmap(b, m, null)
            paint.color = (p.bgColor and 0x00FFFFFF) or 0x55000000
            canvas.drawPath(path, paint)
            canvas.restore()
        }

        // кільце прогресу
        if (p.ringOn) {
            val prog = (rem / p.trigger).coerceIn(0f, 1f)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = s * 0.045f; paint.strokeCap = Paint.Cap.ROUND
            if (p.shape == 2) {
                val y = rect.bottom - s * 0.075f; val x0 = rect.left + r * 0.8f; val x1 = rect.right - r * 0.8f
                paint.color = ringCol; paint.alpha = 60; canvas.drawLine(x0, y, x1, y, paint)
                paint.color = ringCol; canvas.drawLine(x0, y, x0 + (x1 - x0) * prog, y, paint)
            } else {
                val i = s * 0.07f
                val ar = RectF(rect.left + i, rect.top + i, rect.right - i, rect.bottom - i)
                paint.color = ringCol; paint.alpha = 60; canvas.drawArc(ar, -90f, 360f, false, paint)
                paint.color = ringCol; canvas.drawArc(ar, -90f, 360f * prog, false, paint)
            }
        }

        // цифри
        paint.reset(); paint.isAntiAlias = true; paint.typeface = tf; paint.textAlign = Paint.Align.CENTER
        paint.color = if (warn) red else p.textColor
        if (p.glow) paint.setShadowLayer(s * 0.05f, 0f, 0f, paint.color)
        val txt = if (p.decimals && rem < 10f) String.format(Locale.US, "%.1f", rem) else sec.toString()
        paint.textSize = s * 0.44f
        val tw = paint.measureText(txt)
        if (tw > bw * 0.74f) paint.textSize = paint.textSize * bw * 0.74f / tw
        val label = p.shape != 2
        canvas.drawText(txt, cx, cy + paint.textSize * (if (label) 0.28f else 0.35f), paint)
        if (label) {
            paint.clearShadowLayer(); paint.textSize = s * 0.085f; paint.alpha = 170
            canvas.drawText("СЕК", cx, cy + bh * 0.34f, paint)
        }
        canvas.restore()
        if (running) postInvalidateOnAnimation()
    }
}
