package com.nubia.lastsecs

import android.app.*
import android.content.Intent
import android.content.IntentFilter
import android.os.*
import android.provider.Settings
import kotlin.math.abs
import kotlin.math.max

class BatteryService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var p: Prefs
    private var wl: PowerManager.WakeLock? = null
    private var avgI = 0.0
    private var deadline = 0L
    private var haveDl = false
    private var dynCutoff = -1L
    private var zeroSince = 0L
    private var shown = false
    private var boot = 0
    private val hist = ArrayDeque<Pair<Long, Long>>()
    private val loop = object : Runnable {
        override fun run() {
            val next = try { sample() } catch (e: Exception) { 2000L }
            h.postDelayed(this, next)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        p = Prefs(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ls", "Last Seconds", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        startForeground(1, Notification.Builder(this, "ls").setContentTitle("Last Seconds активний")
            .setContentText("Стежу за батареєю").setSmallIcon(android.R.drawable.ic_lock_idle_low_battery)
            .setContentIntent(pi).setOngoing(true).build())
        boot = Settings.Global.getInt(contentResolver, Settings.Global.BOOT_COUNT, 0)
        recover()
    }

    // Якщо після останнього запису телефон перезавантажився на низькому заряді — це було вимкнення. Запам'ятовуємо відсічку.
    private fun recover() {
        if (p.lastDis && p.lastBoot != 0 && boot != p.lastBoot && p.lastLevel <= 8) {
            val l = (p.history.split(",").filter { it.isNotEmpty() }.map { it.toLong() } + p.lastCharge).takeLast(5)
            p.history = l.joinToString(",")
            p.learnedCutoff = l.sorted()[l.size / 2]
        }
        p.lastDis = false
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (!p.enabled) { stopSelf(); return START_NOT_STICKY }
        h.removeCallbacks(loop); h.post(loop)
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(loop)
        if (shown) Overlay.hide()
        try { wl?.release() } catch (e: Exception) { }
        super.onDestroy()
    }

    private fun sample(): Long {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return 2000L
        val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100f / b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val charging = b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val now = SystemClock.elapsedRealtime()
        Live.level = lvl; Live.charging = charging

        if (charging) {
            if (shown) { shown = false; Overlay.hide() }
            haveDl = false; avgI = 0.0; hist.clear(); dynCutoff = -1; zeroSince = 0; Live.est = -1f
            try { wl?.release() } catch (e: Exception) { }
            wl = null
            p.sp.edit().putBoolean("ld", false).apply()
            return 5000L
        }

        var cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) // мкА·год
        val ccOk = cc > 0
        if (!ccOk) cc = (lvl * 50000).toLong() // запасний варіант: 5000 мА·год
        if (ccOk && lvl >= 30) {
            val fc = (cc * 100 / lvl).toLong()
            p.fullCap = if (p.fullCap == 0L) fc else (p.fullCap * 0.9 + fc * 0.1).toLong()
        }

        val raw = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        var cur = if (raw == Long.MIN_VALUE) 0.0 else abs(raw).toDouble()
        if (cur in 1.0..19999.0) cur *= 1000 // деякі прошивки віддають мА
        if (cur > 0) avgI = if (avgI == 0.0) cur else avgI * 0.8 + cur * 0.2

        hist.addLast(now to cc)
        while (hist.size > 1 && now - hist.first().first > 30000) hist.removeFirst()
        var i = avgI
        if (ccOk && hist.size > 1) {
            val o = hist.first(); val dt = (now - o.first) / 1000.0
            if (dt >= 15 && o.second > cc) {
                val sl = (o.second - cc) / dt * 3600
                i = if (i > 0) 0.5 * i + 0.5 * sl else sl
            }
        }
        if (i <= 0) i = 300000.0

        val cutoff = when {
            dynCutoff > 0 -> dynCutoff
            p.autoCal && p.learnedCutoff > 0 -> p.learnedCutoff
            else -> ((if (p.fullCap > 0) p.fullCap else 5_000_000L) * p.cutoffTenths / 1000.0).toLong()
        }
        val remS = max(0.0, max(0.0, (cc - cutoff).toDouble()) / i * 3600.0 + p.offset)
        Live.est = remS.toFloat(); Live.ma = (i / 1000).toFloat(); Live.cutoff = cutoff

        val target = now + (remS * 1000).toLong()
        if (!haveDl || remS > p.trigger + 30) { deadline = target; haveDl = true }
        else deadline += ((target - deadline) * 0.35).toLong()

        if (remS <= p.trigger) {
            if (!shown) shown = Overlay.show(this, false) { max(0f, (deadline - SystemClock.elapsedRealtime()) / 1000f) }
        } else if (remS > p.trigger + 20 && shown) { shown = false; Overlay.hide() }

        // таймер дійшов до 0, а телефон живий — відсічка була завищена, зсуваємо
        if (cc <= cutoff) {
            if (zeroSince == 0L) zeroSince = now
            else if (now - zeroSince > 4000) { dynCutoff = (cc - i * 8 / 3600).toLong(); zeroSince = now }
        } else zeroSince = 0

        if (lvl <= 15) p.sp.edit().putLong("lc", cc).putInt("ll", lvl.toInt()).putInt("lb", boot).putBoolean("ld", true).commit()

        if (lvl <= 10) {
            if (wl == null) wl = (getSystemService(POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lastsecs:w").also { it.acquire(3600_000L) }
        } else if (lvl > 12) { try { wl?.release() } catch (e: Exception) { }; wl = null }

        return when {
            shown || remS < 120 -> 500L
            lvl <= 15 -> 1000L
            lvl <= 25 -> 3000L
            else -> 10000L
        }
    }
}
