package com.nubia.lastsecs

import android.content.Context
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import java.io.File

object Overlay {
    private var view: TimerView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var wm: WindowManager? = null
    private var ctx: Context? = null
    private var mp: MediaPlayer? = null
    private var tone: ToneGenerator? = null
    private var played = false

    fun show(c: Context, touchable: Boolean, supplier: () -> Float): Boolean {
        val a = c.applicationContext
        if (!Settings.canDrawOverlays(a)) return false
        hide(); ctx = a; played = false
        val p = Prefs(a)
        val w = a.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = w
        val v = TimerView(a, supplier)
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val l = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        view = v; lp = l
        calc()
        v.onSecond = { sec -> sound(sec) }
        if (touchable) v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_MOVE || e.action == MotionEvent.ACTION_DOWN) {
                val dm = a.resources.displayMetrics
                p.xf = (e.rawX / dm.widthPixels).coerceIn(0f, 1f)
                p.yf = (e.rawY / dm.heightPixels).coerceIn(0f, 1f)
                place()
            }
            true
        }
        v.alpha = 0f; v.scaleX = 0.3f; v.scaleY = 0.3f
        w.addView(v, l)
        v.animate().alpha(p.opacity / 100f).scaleX(1f).scaleY(1f).setDuration(450)
            .setInterpolator(OvershootInterpolator(2f)).start()
        return true
    }

    private fun calc() {
        val v = view ?: return; val l = lp ?: return; val a = ctx ?: return
        val dm = a.resources.displayMetrics; val p = Prefs(a)
        l.x = (p.xf * dm.widthPixels - v.w() / 2f).toInt()
        l.y = (p.yf * dm.heightPixels - v.h() / 2f).toInt()
    }

    private fun place() {
        calc()
        val v = view ?: return
        if (v.isAttachedToWindow) try { wm?.updateViewLayout(v, lp) } catch (e: Exception) { }
    }

    fun refresh() {
        val v = view ?: return
        v.reload(); v.alpha = Prefs(ctx!!).opacity / 100f; place()
    }

    fun hide() {
        val v = view ?: return
        view = null; stopSound()
        v.animate().alpha(0f).scaleX(0.5f).scaleY(0.5f).setDuration(250).withEndAction {
            try { wm?.removeView(v) } catch (e: Exception) { }
        }.start()
    }

    private fun sound(sec: Int) {
        val a = ctx ?: return; val p = Prefs(a)
        if (p.vibrate) try {
            @Suppress("DEPRECATION")
            (a.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                .vibrate(VibrationEffect.createOneShot(if (sec <= 5) 140L else 40L, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) { }
        when (p.soundMode) {
            1 -> play(a, false, sec)
            2 -> if (!played) { played = true; play(a, false, sec) }
            3 -> if (!played) { played = true; play(a, true, sec) }
        }
    }

    private fun play(a: Context, loop: Boolean, sec: Int) {
        val f = Prefs(a).soundFile
        if (f.isNotEmpty() && File(f).exists()) try {
            mp?.release()
            mp = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                setDataSource(f); isLooping = loop; prepare(); start()
            }
            return
        } catch (e: Exception) { }
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            tone?.startTone(if (sec <= 5) ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD else ToneGenerator.TONE_PROP_BEEP, 180)
        } catch (e: Exception) { }
    }

    private fun stopSound() {
        try { mp?.release() } catch (e: Exception) { }
        mp = null
        try { tone?.release() } catch (e: Exception) { }
        tone = null
    }
}
