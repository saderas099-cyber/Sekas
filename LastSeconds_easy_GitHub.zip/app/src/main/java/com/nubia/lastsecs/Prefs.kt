package com.nubia.lastsecs

import android.content.Context
import android.content.SharedPreferences
import kotlin.reflect.KProperty

class Pref<T : Any>(private val sp: SharedPreferences, private val k: String, private val d: T) {
    @Suppress("UNCHECKED_CAST")
    operator fun getValue(r: Any?, p: KProperty<*>): T = when (d) {
        is Int -> sp.getInt(k, d)
        is Long -> sp.getLong(k, d)
        is Float -> sp.getFloat(k, d)
        is Boolean -> sp.getBoolean(k, d)
        else -> sp.getString(k, d as String) ?: d
    } as T

    operator fun setValue(r: Any?, p: KProperty<*>, v: T) {
        val e = sp.edit()
        when (v) {
            is Int -> e.putInt(k, v)
            is Long -> e.putLong(k, v)
            is Float -> e.putFloat(k, v)
            is Boolean -> e.putBoolean(k, v)
            else -> e.putString(k, v as String)
        }
        e.apply()
    }
}

class Prefs(c: Context) {
    val sp: SharedPreferences = c.applicationContext.getSharedPreferences("lastsecs", Context.MODE_PRIVATE)
    var enabled by Pref(sp, "enabled", false)
    var trigger by Pref(sp, "trigger", 30)
    var offset by Pref(sp, "offset", 0)
    var cutoffTenths by Pref(sp, "cut10", 10)
    var autoCal by Pref(sp, "autocal", true)
    var learnedCutoff by Pref(sp, "learned", 0L)
    var fullCap by Pref(sp, "fullcap", 0L)
    var history by Pref(sp, "hist", "")
    var lastCharge by Pref(sp, "lc", 0L)
    var lastLevel by Pref(sp, "ll", 100)
    var lastBoot by Pref(sp, "lb", 0)
    var lastDis by Pref(sp, "ld", false)
    var xf by Pref(sp, "xf", 0.5f)
    var yf by Pref(sp, "yf", 0.22f)
    var sizeDp by Pref(sp, "size", 190)
    var opacity by Pref(sp, "opacity", 100)
    var shape by Pref(sp, "shape", 0)
    var textColor by Pref(sp, "tc", 0xFFFFFFFF.toInt())
    var bgColor by Pref(sp, "bc", 0xCC0B0B1F.toInt())
    var bgColor2 by Pref(sp, "bc2", 0xCC3A1C71.toInt())
    var useGradient by Pref(sp, "grad", true)
    var bgImage by Pref(sp, "bgimg", "")
    var ringOn by Pref(sp, "ring", true)
    var ringColor by Pref(sp, "rc", 0xFF00E5FF.toInt())
    var glow by Pref(sp, "glow", true)
    var pulse by Pref(sp, "pulse", true)
    var shake by Pref(sp, "shake", true)
    var warnRed by Pref(sp, "warn", true)
    var font by Pref(sp, "font", 3)
    var fontFile by Pref(sp, "fontfile", "")
    var decimals by Pref(sp, "dec", true)
    var soundMode by Pref(sp, "smode", 1)
    var soundFile by Pref(sp, "sfile", "")
    var vibrate by Pref(sp, "vib", true)
}

object Live {
    @Volatile var level = -1f
    @Volatile var charging = false
    @Volatile var est = -1f
    @Volatile var ma = 0f
    @Volatile var cutoff = 0L
}
