package com.nubia.lastsecs

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs(c).enabled) c.startForegroundService(Intent(c, BatteryService::class.java))
    }
}
