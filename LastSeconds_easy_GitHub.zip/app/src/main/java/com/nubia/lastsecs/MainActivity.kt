package com.nubia.lastsecs

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.View
import android.widget.*
import java.io.File
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var p: Prefs
    private lateinit var preview: TimerView
    private lateinit var status: TextView
    private lateinit var perm: TextView
    private lateinit var list: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private val syncs = ArrayList<() -> Unit>()
    private val W = Color.WHITE
    private val M = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val t0 = SystemClock.elapsedRealtime()
    private var testT0 = 0L
    private val swatches = listOf(0xFFFFFFFFL, 0xFF00E5FFL, 0xFFFF2D95L, 0xFFFFD60AL, 0xFF30D158L, 0xFFFF3B30L,
        0xFF7C4DFFL, 0xFFFF9500L, 0xFF000000L, 0xFF101020L, 0xFF3A1C71L, 0xFF0A84FFL).map { it.toInt() }

    private fun c(v: Long) = v.toInt()
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun rounded(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = Prefs(this)
        window.statusBarColor = c(0xFF0B0F1FL); window.navigationBarColor = c(0xFF0B0F1FL)
        val root = FrameLayout(this)
        val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c(0xFF0B0F1FL), c(0xFF140A33L), c(0xFF06222EL)))
        val ev = ArgbEvaluator()
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 7000; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                bg.colors = intArrayOf(
                    ev.evaluate(f, c(0xFF0B0F1FL), c(0xFF1E0B4AL)) as Int,
                    ev.evaluate(f, c(0xFF140A33L), c(0xFF06303FL)) as Int,
                    ev.evaluate(f, c(0xFF06222EL), c(0xFF2A0A3AL)) as Int)
            }
            start()
        }
        root.background = bg
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(col, FrameLayout.LayoutParams(M, M))
        col.addView(TextView(this).apply {
            text = "⚡ LAST SECONDS"; setTextColor(W); textSize = 20f; letterSpacing = 0.12f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL); setPadding(dp(20), dp(36), dp(20), dp(6))
        })
        val box = FrameLayout(this).apply { background = rounded(0x44000000, 22, 0x44FFFFFF); clipChildren = true }
        preview = TimerView(this) { 30f - ((SystemClock.elapsedRealtime() - t0) / 1000f) % 30f }
        box.addView(preview, FrameLayout.LayoutParams(WC, WC, Gravity.CENTER))
        col.addView(box, LinearLayout.LayoutParams(M, dp(230)).apply { setMargins(dp(16), dp(4), dp(16), dp(8)) })
        val sv = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(40)) }
        sv.addView(list)
        col.addView(sv, LinearLayout.LayoutParams(M, 0, 1f))
        setContentView(root)
        build()
        updatePreview()
        for (i in 0 until list.childCount) list.getChildAt(i).apply {
            alpha = 0f; translationY = dp(40).toFloat()
            animate().alpha(1f).translationY(0f).setStartDelay(100L + i * 70L).setDuration(500).start()
        }
    }

    private fun changed() { preview.reload(); updatePreview(); Overlay.refresh() }

    private fun updatePreview() {
        val k = minOf(1f, dp(215).toFloat() / preview.h(), dp(330).toFloat() / preview.w())
        preview.scaleX = k; preview.scaleY = k
    }

    // ---------- екран ----------
    private fun build() {
        card("Головне").apply {
            sw("Захист увімкнено", { p.enabled }) { v ->
                p.enabled = v
                val i = Intent(this@MainActivity, BatteryService::class.java)
                if (v) startForegroundService(i) else stopService(i)
            }
            status = TextView(context).apply { setTextColor(0xCCFFFFFF.toInt()); textSize = 13f; setPadding(0, dp(6), 0, dp(4)) }
            addView(status)
            btn("▶ Показати таймер на екрані (тест, можна тягнути)") {
                if (!Settings.canDrawOverlays(this@MainActivity)) { toast("Спершу дай дозвіл «Поверх інших вікон»"); return@btn }
                testT0 = SystemClock.elapsedRealtime()
                Overlay.show(this@MainActivity, true) { 30f - ((SystemClock.elapsedRealtime() - testT0) / 1000f) % 30f }
            }
            btn("■ Сховати тест") { Overlay.hide() }
        }
        card("Дозволи (обов'язково)").apply {
            perm = TextView(context).apply { setTextColor(W); textSize = 13f; setPadding(0, 0, 0, dp(4)) }
            addView(perm)
            btn("1. Поверх інших вікон") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            btn("2. Сповіщення") {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
                else toast("На цій версії не потрібно")
            }
            btn("3. Без обмежень батареї") {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
            btn("4. Налаштування додатка (автозапуск)") {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }
        card("Коли показувати").apply {
            slider("Показувати за", 5, 60, { p.trigger }, { p.trigger = it }) { "$it с до вимкнення" }
        }
        card("Тема").apply {
            chips(listOf("Неон", "Лава", "Лід", "Матриця", "Мінімал"), { -1 }, { preset(it) })
        }
        card("Вигляд і місце").apply {
            chips(listOf("Квадрат", "Коло", "Таблетка"), { p.shape }, { p.shape = it })
            slider("Розмір", 80, 400, { p.sizeDp }, { p.sizeDp = it }) { "$it dp" }
            slider("Позиція X", 0, 100, { (p.xf * 100).toInt() }, { p.xf = it / 100f }) { "$it %" }
            slider("Позиція Y", 0, 100, { (p.yf * 100).toInt() }, { p.yf = it / 100f }) { "$it %" }
            slider("Прозорість", 20, 100, { p.opacity }, { p.opacity = it }) { "$it %" }
        }
        card("Кольори").apply {
            colorRow("Колір цифр", { p.textColor }, { p.textColor = it })
            colorRow("Фон (8 цифр HEX = з прозорістю AARRGGBB)", { p.bgColor }, { p.bgColor = it })
            sw("Градієнт фону", { p.useGradient }) { p.useGradient = it }
            colorRow("Другий колір градієнта", { p.bgColor2 }, { p.bgColor2 = it })
            colorRow("Колір кільця й світіння", { p.ringColor }, { p.ringColor = it })
        }
        card("Шрифт і цифри").apply {
            chips(listOf("Звичайний", "Serif", "Mono", "Жирний", "Тонкий", "Вузький", "Рукопис", "Свій"), { p.font }, { p.font = it })
            btn("Завантажити свій шрифт (.ttf / .otf)") { pick(3, arrayOf("*/*")) }
            sw("Десяті частки в останні 10 с", { p.decimals }) { p.decimals = it }
        }
        card("Фон-картинка").apply {
            btn("Вибрати картинку") { pick(1, arrayOf("image/*")) }
            btn("Прибрати картинку") { p.bgImage = ""; changed() }
        }
        card("Ефекти").apply {
            sw("Кільце прогресу", { p.ringOn }) { p.ringOn = it }
            sw("Неонове світіння", { p.glow }) { p.glow = it }
            sw("Пульс на кожну секунду", { p.pulse }) { p.pulse = it }
            sw("Тряска в останні 5 с", { p.shake }) { p.shake = it }
            sw("Червоний у останні 5 с", { p.warnRed }) { p.warnRed = it }
        }
        card("Звук і вібрація").apply {
            chips(listOf("Без звуку", "Кожну секунду", "Раз на старті", "Цикл"), { p.soundMode }, { p.soundMode = it })
            btn("Вибрати свій звук (mp3 / wav / ogg)") { pick(2, arrayOf("audio/*")) }
            btn("Стандартний звук") { p.soundFile = ""; toast("Буде стандартний сигнал") }
            sw("Вібрація", { p.vibrate }) { p.vibrate = it }
        }
        card("Точність (головне)").apply {
            slider("Запасна відсічка (до першого вимкнення)", 0, 80, { p.cutoffTenths }, { p.cutoffTenths = it }) { "%.1f %%".format(it / 10f) }
            slider("Підстроювання часу", -20, 20, { p.offset }, { p.offset = it }) { "$it с" }
            sw("Авто-калібрування по реальних вимкненнях", { p.autoCal }) { p.autoCal = it }
            btn("Скинути калібрування") { p.learnedCutoff = 0; p.history = ""; toast("Скинуто") }
            addView(TextView(context).apply {
                setTextColor(0x99FFFFFF.toInt()); textSize = 12f; setPadding(0, dp(8), 0, 0)
                text = "Після кожного реального вимкнення додаток запам'ятовує, при якому заряді телефон вимкнувся (бере середнє з 5 останніх). " +
                    "Якщо таймер досяг 0, а телефон ще живий — відсічка сама зсувається нижче. Якщо щоразу рано/пізно — крутни «Підстроювання»."
            })
        }
        card("Поради для nubia / ZTE").apply {
            addView(TextView(context).apply {
                setTextColor(0xCCFFFFFF.toInt()); textSize = 13f
                text = "• Налаштування → Додатки → Last Seconds → Автозапуск: увімкни.\n" +
                    "• Батарея → Last Seconds → Без обмежень.\n" +
                    "• У меню останніх додатків потягни картку вниз і натисни замок 🔒, щоб додаток не вбивало.\n" +
                    "• Після встановлення відкрий додаток, дай 3 дозволи і увімкни перемикач «Захист»."
            })
        }
    }

    private fun preset(i: Int) {
        when (i) {
            0 -> { p.textColor = c(0xFFFFFFFFL); p.bgColor = c(0xCC0B0B1FL); p.bgColor2 = c(0xCC3A1C71L); p.ringColor = c(0xFF00E5FFL); p.font = 3; p.shape = 0 }
            1 -> { p.textColor = c(0xFFFFF3E0L); p.bgColor = c(0xDD3B0A0AL); p.bgColor2 = c(0xDDB53A00L); p.ringColor = c(0xFFFFB300L); p.font = 3; p.shape = 1 }
            2 -> { p.textColor = c(0xFF0A2540L); p.bgColor = c(0xDDE8F6FFL); p.bgColor2 = c(0xDD9AD0FFL); p.ringColor = c(0xFF0A84FFL); p.font = 0; p.shape = 0 }
            3 -> { p.textColor = c(0xFF39FF14L); p.bgColor = c(0xEE000800L); p.bgColor2 = c(0xEE002A06L); p.ringColor = c(0xFF39FF14L); p.font = 2; p.shape = 0 }
            else -> { p.textColor = c(0xFFFFFFFFL); p.bgColor = c(0xCC000000L); p.ringColor = c(0xFFFFFFFFL); p.font = 4; p.shape = 2 }
        }
        p.useGradient = i != 4
        changed(); recreate()
    }

    // ---------- будівельні блоки ----------
    private fun card(title: String): LinearLayout {
        val cd = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(16))
            background = rounded(0x2AFFFFFF, 20, 0x33FFFFFF)
        }
        cd.addView(TextView(this).apply {
            text = title.uppercase(); setTextColor(c(0xFF00E5FFL)); textSize = 12f; letterSpacing = 0.15f
            typeface = Typeface.DEFAULT_BOLD; setPadding(0, 0, 0, dp(8))
        })
        list.addView(cd, LinearLayout.LayoutParams(M, WC).apply { bottomMargin = dp(12) })
        return cd
    }

    private fun LinearLayout.btn(label: String, onClick: () -> Unit) {
        val t = TextView(context).apply {
            text = label; setTextColor(W); textSize = 14f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c(0xFF7C4DFFL), c(0xFF00B8D4L)))
                .apply { cornerRadius = dp(14).toFloat() }
            setOnClickListener { onClick() }
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(80).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
                false
            }
        }
        addView(t, LinearLayout.LayoutParams(M, WC).apply { topMargin = dp(8) })
    }

    private fun LinearLayout.sw(label: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        addView(Switch(context).apply {
            text = label; setTextColor(W); isChecked = get(); setPadding(0, dp(6), 0, dp(6))
            setOnCheckedChangeListener { _, v -> set(v); changed() }
        })
    }

    private fun LinearLayout.slider(label: String, lo: Int, hi: Int, get: () -> Int, set: (Int) -> Unit, fmt: (Int) -> String) {
        val tv = TextView(context).apply { setTextColor(W); textSize = 14f; setPadding(0, dp(8), 0, 0) }
        val sb = SeekBar(context).apply {
            max = hi - lo; progress = get() - lo
            progressTintList = android.content.res.ColorStateList.valueOf(c(0xFF00E5FFL))
            thumbTintList = android.content.res.ColorStateList.valueOf(c(0xFFFF2D95L))
        }
        fun upd() { tv.text = "$label: ${fmt(get())}" }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, user: Boolean) { if (user) { set(v + lo); upd(); changed() } }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        syncs.add { if (!sb.isPressed) { sb.progress = get() - lo; upd() } }
        upd(); addView(tv); addView(sb)
    }

    private fun LinearLayout.chips(opts: List<String>, get: () -> Int, set: (Int) -> Unit) {
        val row = LinearLayout(context)
        val btns = ArrayList<TextView>()
        fun paintAll() = btns.forEachIndexed { i, t ->
            val on = i == get()
            t.background = rounded(if (on) c(0xFF00E5FFL) else 0x33FFFFFF, 18)
            t.setTextColor(if (on) c(0xFF001018L) else W)
        }
        opts.forEachIndexed { i, s ->
            val t = TextView(context).apply {
                text = s; textSize = 13f; setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener { set(i); paintAll(); changed() }
            }
            btns.add(t); row.addView(t, LinearLayout.LayoutParams(WC, WC).apply { rightMargin = dp(8) })
        }
        paintAll()
        addView(HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false; addView(row) },
            LinearLayout.LayoutParams(M, WC).apply { bottomMargin = dp(4) })
    }

    private fun LinearLayout.colorRow(label: String, get: () -> Int, set: (Int) -> Unit) {
        addView(TextView(context).apply { text = label; setTextColor(W); textSize = 14f; setPadding(0, dp(10), 0, dp(4)) })
        val hex = EditText(context).apply {
            setTextColor(W); textSize = 13f; setSingleLine(); imeOptions = EditorInfo.IME_ACTION_DONE
            setText(String.format("%08X", get()))
        }
        val row = LinearLayout(context)
        swatches.forEach { sw ->
            val v = View(context).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(sw); setStroke(dp(2), 0x66FFFFFF) }
                setOnClickListener {
                    val n = (sw and 0xFFFFFF) or (get() and c(0xFF000000L))
                    set(n); hex.setText(String.format("%08X", n)); changed()
                }
            }
            row.addView(v, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(8) })
        }
        hex.setOnEditorActionListener { _, _, _ ->
            try {
                var s = hex.text.toString().trim().removePrefix("#")
                if (s.length == 6) s = "FF$s"
                set(s.toLong(16).toInt()); changed()
            } catch (e: Exception) { toast("Формат: RRGGBB або AARRGGBB") }
            false
        }
        addView(HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        addView(hex)
    }

    // ---------- файли ----------
    private fun pick(req: Int, mimes: Array<String>) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, mimes)
        }, req)
    }

    private fun copy(u: Uri, n: String): String {
        filesDir.listFiles()?.filter { it.name.startsWith(n) }?.forEach { it.delete() }
        val f = File(filesDir, n + System.currentTimeMillis())
        contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        return f.absolutePath
    }

    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        val u = d?.data ?: return
        if (res != RESULT_OK) return
        try {
            when (r) {
                1 -> p.bgImage = copy(u, "bg")
                2 -> { p.soundFile = copy(u, "snd"); p.soundMode = if (p.soundMode == 0) 1 else p.soundMode }
                3 -> { p.fontFile = copy(u, "font"); p.font = 7 }
            }
            changed()
            if (r == 3 || r == 2) recreate()
        } catch (e: Exception) { toast("Не вдалося відкрити файл") }
    }

    // ---------- статус ----------
    private fun refreshPerm() {
        val ov = Settings.canDrawOverlays(this)
        val bat = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        val nt = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        perm.text = "${if (ov) "✅" else "❌"} Поверх вікон    ${if (nt) "✅" else "❌"} Сповіщення    ${if (bat) "✅" else "❌"} Без обмежень"
    }

    private val poll = object : Runnable {
        override fun run() {
            val l = Live
            status.text = when {
                l.level < 0 -> "Служба ще не працює — увімкни перемикач вище"
                l.charging -> "🔌 Зарядка: ${l.level.toInt()}% — таймер спить"
                else -> String.format(Locale.US,
                    "🔋 %.0f%% · струм %.0f мА\n⏱ До вимкнення ≈ %.0f с\nВідсічка %.0f мАг · повна %.0f мАг · вимкнень записано: %d",
                    l.level, l.ma, l.est, l.cutoff / 1000f, p.fullCap / 1000f, p.history.split(",").count { it.isNotEmpty() })
            }
            syncs.forEach { it() }
            h.postDelayed(this, 1000)
        }
    }

    override fun onResume() { super.onResume(); refreshPerm(); h.post(poll) }
    override fun onPause() { super.onPause(); h.removeCallbacks(poll) }
}
