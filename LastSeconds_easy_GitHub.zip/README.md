# LastSeconds

Android project. GitHub Actions builds a debug APK at every push or when manually started.

## Build
1. Upload the **contents** of this folder to the root of a GitHub repository (not this folder as a nested folder and not the ZIP itself).
2. Open **Actions** and allow workflows if GitHub asks.
3. Open the **Build APK** workflow and tap **Run workflow** (or wait for the first push build).
4. Open the completed run and download **LastSeconds-apk** from Artifacts.

The APK is a debug-signed APK for testing, not a Play Store release.
